`timescale 1ns / 1ps
// Nexys A7-100T board wrapper:
// SW[3:0] = operand A, SW[7:4] = operand B, SW[10:8] = opcode
// LD[3:0] = result, LD4 = carry/no-borrow, LD5 = zero, LD6 = overflow
module alu_4bit_nexys_a7 (
    input  wire [10:0] SW,
    output wire [6:0]  LD
);
    wire [3:0] result;
    wire carry_out, zero, overflow;

    alu_4bit u_alu (
        .A(SW[3:0]),
        .B(SW[7:4]),
        .opcode(SW[10:8]),
        .result(result),
        .carry_out(carry_out),
        .zero(zero),
        .overflow(overflow)
    );

    assign LD[3:0] = result;
    assign LD[4]   = carry_out;
    assign LD[5]   = zero;
    assign LD[6]   = overflow;
endmodule
