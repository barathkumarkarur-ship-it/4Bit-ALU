`timescale 1ns / 1ps
// 4-bit combinational ALU for Digilent Nexys A7-100T (Artix-7)
// Opcode map:
// 000 ADD, 001 SUB, 010 AND, 011 OR,
// 100 XOR, 101 NOT A, 110 SHIFT LEFT A, 111 SHIFT RIGHT A
module alu_4bit (
    input  wire [3:0] A,
    input  wire [3:0] B,
    input  wire [2:0] opcode,
    output reg  [3:0] result,
    output reg        carry_out,
    output reg        zero,
    output reg        overflow
);
    reg [4:0] temp;

    always @* begin
        result    = 4'b0000;
        carry_out = 1'b0;
        overflow  = 1'b0;
        temp      = 5'b00000;

        case (opcode)
            3'b000: begin // ADD
                temp      = {1'b0, A} + {1'b0, B};
                result    = temp[3:0];
                carry_out = temp[4];
                overflow  = (~(A[3] ^ B[3])) & (result[3] ^ A[3]);
            end
            3'b001: begin // SUB
                result    = A - B;
                carry_out = (A >= B); // 1 means no borrow
                overflow  = (A[3] ^ B[3]) & (result[3] ^ A[3]);
            end
            3'b010: result = A & B;
            3'b011: result = A | B;
            3'b100: result = A ^ B;
            3'b101: result = ~A;
            3'b110: begin
                result    = A << 1;
                carry_out = A[3];
            end
            3'b111: begin
                result    = A >> 1;
                carry_out = A[0];
            end
            default: result = 4'b0000;
        endcase

        zero = (result == 4'b0000);
    end
endmodule
