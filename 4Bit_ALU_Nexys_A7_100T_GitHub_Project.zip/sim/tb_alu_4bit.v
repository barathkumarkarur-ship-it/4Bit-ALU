`timescale 1ns / 1ps
module tb_alu_4bit;
    reg [3:0] A, B;
    reg [2:0] opcode;
    wire [3:0] result;
    wire carry_out, zero, overflow;

    alu_4bit dut (
        .A(A), .B(B), .opcode(opcode),
        .result(result), .carry_out(carry_out),
        .zero(zero), .overflow(overflow)
    );

    task check;
        input [3:0] a_in, b_in;
        input [2:0] op_in;
        input [3:0] expected;
        begin
            A = a_in; B = b_in; opcode = op_in;
            #10;
            if (result !== expected)
                $display("FAIL A=%h B=%h OP=%b expected=%h got=%h",
                         A, B, opcode, expected, result);
            else
                $display("PASS A=%h B=%h OP=%b RESULT=%h C=%b Z=%b V=%b",
                         A, B, opcode, result, carry_out, zero, overflow);
        end
    endtask

    initial begin
        $dumpfile("alu_4bit.vcd");
        $dumpvars(0, tb_alu_4bit);

        check(4'd5, 4'd3, 3'b000, 4'd8);  // ADD
        check(4'd9, 4'd4, 3'b001, 4'd5);  // SUB
        check(4'hC, 4'hA, 3'b010, 4'h8);  // AND
        check(4'hC, 4'hA, 3'b011, 4'hE);  // OR
        check(4'hC, 4'hA, 3'b100, 4'h6);  // XOR
        check(4'h5, 4'h0, 3'b101, 4'hA);  // NOT A
        check(4'h9, 4'h0, 3'b110, 4'h2);  // SHIFT LEFT
        check(4'h9, 4'h0, 3'b111, 4'h4);  // SHIFT RIGHT

        #10;
        $display("ALU testbench completed.");
        $finish;
    end
endmodule
