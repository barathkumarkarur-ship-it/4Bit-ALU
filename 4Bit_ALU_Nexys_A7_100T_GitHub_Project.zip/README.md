# 4-Bit ALU on Nexys A7-100T (Artix-7)

A beginner-friendly Verilog project implementing an 8-operation, 4-bit Arithmetic Logic Unit (ALU) for the Digilent Nexys A7-100T FPGA board using Xilinx Vivado.

## Features
- 4-bit operands A and B
- 3-bit operation selector
- Arithmetic: addition and subtraction
- Logic: AND, OR, XOR, NOT A
- Shifts: left shift and right shift
- Status outputs: carry/no-borrow, zero, and signed overflow

## Board switch and LED mapping
| Board control | Purpose |
|---|---|
| SW0-SW3 | Operand A (A[0] through A[3]) |
| SW4-SW7 | Operand B (B[0] through B[3]) |
| SW8-SW10 | Opcode (opcode[0] through opcode[2]) |
| LD0-LD3 | Result (result[0] through result[3]) |
| LD4 | Carry for ADD / no-borrow for SUB / shifted-out bit for shifts |
| LD5 | Zero flag |
| LD6 | Signed overflow flag |

Switch bits are assigned in ascending order. For example, A=5 (0101) means SW0=1, SW1=0, SW2=1, SW3=0.

## Opcode table
| Opcode | Operation | Description |
|---|---|---|
| 000 | ADD | A + B |
| 001 | SUB | A - B |
| 010 | AND | A AND B |
| 011 | OR | A OR B |
| 100 | XOR | A XOR B |
| 101 | NOT A | Bitwise complement of A |
| 110 | SHIFT LEFT | A shifted left by one bit |
| 111 | SHIFT RIGHT | A shifted right by one bit |

## Project files
- `rtl/alu_4bit.v` — ALU logic
- `rtl/alu_4bit_nexys_a7.v` — Nexys A7 board wrapper
- `sim/tb_alu_4bit.v` — simulation testbench
- `constraints/Nexys-A7-100T.xdc` — switch and LED pin constraints
- `docs/images/alu_block_diagram.png` — functional block diagram
- `docs/images/alu_opcode_table.png` — operation reference graphic
- `docs/images/illustrative_simulation_waveform.png` — illustrative timing example, not a Vivado capture

## Run in Vivado
1. Create a new RTL project and select the Nexys A7-100T device: `xc7a100t-1csg324-1`.
2. Add both files from `rtl/` as design sources.
3. Set `alu_4bit_nexys_a7` as the top module.
4. Add `constraints/Nexys-A7-100T.xdc`.
5. Add `sim/tb_alu_4bit.v` as a simulation source and set `tb_alu_4bit` as simulation top.
6. Run Behavioral Simulation. The testbench prints PASS/FAIL results in the Tcl console.
7. For hardware, run Synthesis, Implementation, Generate Bitstream, then program the board.

## Important notes
- This is a combinational ALU; it does not require a clock or reset.
- The waveform graphic is an explanatory illustration only. It is not an actual Vivado simulation screenshot.
- Verify the board revision and pin names against the official Digilent Nexys A7 master XDC before programming hardware.
- During subtraction, LD4 is 1 when A is greater than or equal to B (no borrow); it is not a conventional carry flag.
- Overflow is calculated using signed 4-bit two's-complement rules.

## License
MIT
